package com.zybooks.andrewracicinventoryapplication;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

/**
 * AddItemActivity allows the user to insert a new inventory item.
 * It includes fields for the item name and quantity and stores the item in the database.
 */
public class AddItemActivity extends AppCompatActivity {

    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_item);

        dbHelper = new DatabaseHelper(this);

        final EditText itemNameEditText = findViewById(R.id.editTextItemName);
        final EditText quantityEditText = findViewById(R.id.editTextItemQuantity);
        Button saveButton = findViewById(R.id.buttonSaveItem);

        // When the Save button is tapped, validate input and insert data.
        saveButton.setOnClickListener(view -> {
            String itemName = itemNameEditText.getText().toString().trim();
            String quantityStr = quantityEditText.getText().toString().trim();

            if (itemName.isEmpty() || quantityStr.isEmpty()) {
                Toast.makeText(AddItemActivity.this, "Enter item name and quantity.", Toast.LENGTH_SHORT).show();
            } else {
                int quantity;
                try {
                    quantity = Integer.parseInt(quantityStr);
                } catch (NumberFormatException e) {
                    Toast.makeText(AddItemActivity.this, "Invalid number format.", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (dbHelper.addInventoryItem(itemName, quantity)) {
                    Toast.makeText(AddItemActivity.this, "Item added.", Toast.LENGTH_SHORT).show();
                    finish();  // Close the activity and return to the inventory grid.
                } else {
                    Toast.makeText(AddItemActivity.this, "Failed to add item.", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}