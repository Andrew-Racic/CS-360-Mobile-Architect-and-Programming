package com.zybooks.andrewracicinventoryapplication;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * DatabaseHelper manages the SQLite database.
 * This class creates the necessary tables and provides CRUD methods
 * for both user accounts and inventory items.
 */
public class DatabaseHelper extends SQLiteOpenHelper {

    // Database configuration
    private static final String DATABASE_NAME = "inventory.db";
    private static final int DATABASE_VERSION = 1;

    // Users table constants
    public static final String TABLE_USERS = "users";
    public static final String COL_USER_ID = "id";
    public static final String COL_USERNAME = "username";
    public static final String COL_PASSWORD = "password";

    // Inventory table constants
    public static final String TABLE_INVENTORY = "inventory";
    public static final String COL_ITEM_ID = "id";
    public static final String COL_ITEM_NAME = "item_name";
    public static final String COL_QUANTITY = "quantity";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    // Called the first time the database is created.
    @Override
    public void onCreate(SQLiteDatabase db) {
        // SQL command to create the users table.
        String createUsersTable = "CREATE TABLE " + TABLE_USERS + " (" +
                COL_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_USERNAME + " TEXT UNIQUE, " +
                COL_PASSWORD + " TEXT" +
                ");";
        db.execSQL(createUsersTable);

        // SQL command to create the inventory table.
        String createInventoryTable = "CREATE TABLE " + TABLE_INVENTORY + " (" +
                COL_ITEM_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_ITEM_NAME + " TEXT, " +
                COL_QUANTITY + " INTEGER" +
                ");";
        db.execSQL(createInventoryTable);
    }

    // Called when the database version is upgraded.
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // For simplicity, drop the old tables and recreate them.
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_INVENTORY);
        onCreate(db);
    }

    // ================= User CRUD Operations =================

    /**
     * Adds a new user to the users table.
     *
     * @param username The username.
     * @param password The password.
     * @return True if insertion was successful.
     */
    public boolean addUser(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COL_USERNAME, username);
        cv.put(COL_PASSWORD, password);
        long result = db.insert(TABLE_USERS, null, cv);
        db.close();
        return result != -1;
    }

    /**
     * Checks whether the provided username and password exist.
     *
     * @param username The username.
     * @param password The password.
     * @return True if the credentials match.
     */
    public boolean checkUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT * FROM " + TABLE_USERS + " WHERE " + COL_USERNAME + "=? AND " + COL_PASSWORD + "=?";
        Cursor cursor = db.rawQuery(query, new String[]{username, password});
        boolean exists = cursor.getCount() > 0;
        cursor.close();
        db.close();
        return exists;
    }

    // ================ Inventory CRUD Operations ================

    /**
     * Adds a new inventory item.
     *
     * @param itemName The name of the inventory item.
     * @param quantity The quantity of the item.
     * @return True if the insertion was successful.
     */
    public boolean addInventoryItem(String itemName, int quantity) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COL_ITEM_NAME, itemName);
        cv.put(COL_QUANTITY, quantity);
        long result = db.insert(TABLE_INVENTORY, null, cv);
        db.close();
        return result != -1;
    }

    /**
     * Returns a Cursor over all inventory items.
     *
     * @return Cursor with inventory data.
     */
    public Cursor getInventoryItems() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM " + TABLE_INVENTORY, null);
    }

    /**
     * Updates the quantity of an inventory item.
     *
     * @param id          The ID of the item.
     * @param newQuantity The new quantity to set.
     * @return True if the update was successful.
     */
    public boolean updateInventoryItem(int id, int newQuantity) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COL_QUANTITY, newQuantity);
        int result = db.update(TABLE_INVENTORY, cv, COL_ITEM_ID + "=?", new String[]{String.valueOf(id)});
        db.close();
        return result > 0;
    }

    /**
     * Deletes an inventory item.
     *
     * @param id The ID of the item to delete.
     * @return True if deletion was successful.
     */
    public boolean deleteInventoryItem(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        int result = db.delete(TABLE_INVENTORY, COL_ITEM_ID + "=?", new String[]{String.valueOf(id)});
        db.close();
        return result > 0;
    }
}