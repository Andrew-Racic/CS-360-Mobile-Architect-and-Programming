package com.zybooks.andrewracicinventoryapplication;

import android.database.Cursor;
import android.os.Bundle;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;

import androidx.appcompat.app.AppCompatActivity;

/**
 * InventoryGridActivity displays all items stored in the inventory
 * in a scrollable list. Each row in the list includes the item name
 * and its current quantity.
 */
public class InventoryGridActivity extends AppCompatActivity {

    private DatabaseHelper dbHelper;
    private ListView listViewInventory;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory_grid);

        dbHelper = new DatabaseHelper(this);
        listViewInventory = findViewById(R.id.listView_inventory);

        // Query the database for inventory items
        Cursor cursor = dbHelper.getInventoryItems();

        // Map from database columns to TextViews in a simple list item layout
        String[] fromColumns = { DatabaseHelper.COL_ITEM_NAME, DatabaseHelper.COL_QUANTITY };
        int[] toViews = { android.R.id.text1, android.R.id.text2 };

        // Create the adapter to bind the data to the ListView
        SimpleCursorAdapter adapter = new SimpleCursorAdapter(
                this,
                android.R.layout.simple_list_item_2,
                cursor,
                fromColumns,
                toViews,
                0
        );
        listViewInventory.setAdapter(adapter);
    }
}